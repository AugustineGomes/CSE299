const typingForm = document.querySelector(".typing-form");
const chatContainer = document.querySelector(".chat-list");
const suggestions = document.querySelectorAll(".suggestion");
const toggleThemeButton = document.querySelector("#theme-toggle-button");
const deleteChatButton = document.querySelector("#delete-chat-button");
const stopResponseButton = document.querySelector("#stop-response-button"); // Stop Button

// State variables
let userMessage = null;
let isResponseGenerating = false;
let shouldStop = false; // Tracks if the user has requested to stop the response

// API configuration
const API_KEY = "AIzaSyBAh45i0b_450mR_INP6Fh-Y5rYSgzkGhQ"; // Your API key here
const API_URL = `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash-8b:generateContent?key=${API_KEY}`;

// Load theme and chat data from local storage on page load
const loadDataFromLocalstorage = () => {
  const savedChats = localStorage.getItem("saved-chats");
  const isLightMode = localStorage.getItem("themeColor") === "light_mode";

  // Apply the stored theme
  document.body.classList.toggle("light_mode", isLightMode);
  toggleThemeButton.innerText = isLightMode ? "dark_mode" : "light_mode";

  // Restore saved chats or clear the chat container
  chatContainer.innerHTML = savedChats || '';
  document.body.classList.toggle("hide-header", !!savedChats);

  chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to the bottom
};

// Create a new message element and return it
const createMessageElement = (content, ...classes) => {
  const div = document.createElement("div");
  div.classList.add("message", ...classes);
  div.innerHTML = content;
  return div;
};

// Show typing effect by displaying words one by one
const showTypingEffect = (text, textElement, incomingMessageDiv) => {
  const words = text.split(' ');
  let currentWordIndex = 0;

  const typingInterval = setInterval(() => {
    // Stop typing if the user clicks the "Stop" button
    if (shouldStop) {
      clearInterval(typingInterval);
      isResponseGenerating = false;
      textElement.innerText += " [Stopped]";
      incomingMessageDiv.querySelector(".icon").classList.remove("hide");
      disableStopButton(); // Disable stop button after stopping
      return;
    }

    // Append each word to the text element with a space
    textElement.innerText += (currentWordIndex === 0 ? '' : ' ') + words[currentWordIndex++];
    incomingMessageDiv.querySelector(".icon").classList.add("hide");

    // If all words are displayed
    if (currentWordIndex === words.length) {
      clearInterval(typingInterval);
      isResponseGenerating = false;
      incomingMessageDiv.querySelector(".icon").classList.remove("hide");
      localStorage.setItem("saved-chats", chatContainer.innerHTML); // Save chats to local storage
      disableStopButton(); // Disable stop button after completion
    }
    chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to the bottom
  }, 75);
};

// Fetch response from the API based on user message
const generateAPIResponse = async (incomingMessageDiv) => {
  const textElement = incomingMessageDiv.querySelector(".text"); // Getting text element

  try {
    // Send a POST request to the API with the user's message
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: userMessage }] }]
      }),
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error.message);

    // Get the API response text and remove asterisks from it
    const apiResponse = data.candidates[0].content.parts[0].text.replace(/\*\*(.*?)\*\*/g, "$1");
    showTypingEffect(apiResponse, textElement, incomingMessageDiv); // Show typing effect
  } catch (error) { // Handle error
    isResponseGenerating = false;
    textElement.innerText = error.message;
    textElement.parentElement.closest(".message").classList.add("error");
    disableStopButton(); // Disable stop button on error
  } finally {
    incomingMessageDiv.classList.remove("loading");
  }
};

// Show a loading animation while waiting for the API response
const showLoadingAnimation = () => {
  const html = `<div class="message-content">
                  <img class="avatar" src="{{url_for('static', filename='gemini.svg')}}" alt="Gemini avatar">
                  <p class="text"></p>
                  <div class="loading-indicator">
                    <div class="loading-bar"></div>
                    <div class="loading-bar"></div>
                    <div class="loading-bar"></div>
                  </div>
                </div>
                <span onClick="copyMessage(this)" class="icon material-symbols-rounded">content_copy</span>`;

  const incomingMessageDiv = createMessageElement(html, "incoming", "loading");
  chatContainer.appendChild(incomingMessageDiv);

  chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to the bottom
  generateAPIResponse(incomingMessageDiv);
};

// Copy message text to the clipboard
const copyMessage = (copyButton) => {
  const messageText = copyButton.parentElement.querySelector(".text").innerText;

  navigator.clipboard.writeText(messageText);
  copyButton.innerText = "done"; // Show confirmation icon
  setTimeout(() => copyButton.innerText = "content_copy", 1000); // Revert icon after 1 second
};

// Handle sending outgoing chat messages
const handleOutgoingChat = () => {
  userMessage = typingForm.querySelector(".typing-input").value.trim() || userMessage;
  if (!userMessage || isResponseGenerating) return; // Exit if there is no message or response is generating

  isResponseGenerating = true;
  enableStopButton(); // Enable stop button when starting response

  const html = `<div class="message-content">
                  <img class="avatar" src="{{url_for('static', filename='user.png')}}" alt="User avatar">
                  <p class="text"></p>
                </div>`;

  const outgoingMessageDiv = createMessageElement(html, "outgoing");
  outgoingMessageDiv.querySelector(".text").innerText = userMessage;
  chatContainer.appendChild(outgoingMessageDiv);

  typingForm.reset(); // Clear input field
  document.body.classList.add("hide-header");
  chatContainer.scrollTo(0, chatContainer.scrollHeight);
  setTimeout(showLoadingAnimation, 500); // Show loading animation after a delay
};

// Enable and disable the stop button
const enableStopButton = () => {
  stopResponseButton.disabled = false;
};

const disableStopButton = () => {
  stopResponseButton.disabled = true;
  shouldStop = false; // Reset stop flag
};

// Add event listener for stop button
stopResponseButton.addEventListener("click", () => {
  if (isResponseGenerating) {
    shouldStop = true; // Request to stop response generation
  }
});

// Toggle between light and dark themes
toggleThemeButton.addEventListener("click", () => {
  const isLightMode = document.body.classList.toggle("light_mode");
  localStorage.setItem("themeColor", isLightMode ? "light_mode" : "dark_mode");
  toggleThemeButton.innerText = isLightMode ? "dark_mode" : "light_mode";
});

// Delete all chats from local storage when button is clicked
deleteChatButton.addEventListener("click", () => {
  if (confirm("Are you sure you want to delete all the chats?")) {
    localStorage.removeItem("saved-chats");
    loadDataFromLocalstorage();
  }
});

// Set userMessage and handle outgoing chat when a suggestion is clicked
suggestions.forEach(suggestion => {
  suggestion.addEventListener("click", () => {
    userMessage = suggestion.querySelector(".text").innerText;
    handleOutgoingChat();
  });
});

// Prevent default form submission and handle outgoing chat
typingForm.addEventListener("submit", (e) => {
  e.preventDefault();
  handleOutgoingChat();
});

// Load data on page load
loadDataFromLocalstorage();
disableStopButton(); // Disable stop button by default



// Array of Quotes (500 Quotes)
const quotes = [
  '"The only way to do great work is to love what you do." – Steve Jobs',
  '"Success is not final, failure is not fatal: It is the courage to continue that counts." – Winston Churchill',
  '"Believe you can and you\'re halfway there." – Theodore Roosevelt',
  '"Education is the most powerful weapon which you can use to change the world." – Nelson Mandela',
  '"The future belongs to those who believe in the beauty of their dreams." – Eleanor Roosevelt',
  '"Do not wait to strike till the iron is hot; but make it hot by striking." – William Butler Yeats',
  '"The best way to predict the future is to create it." – Peter Drucker',
  '"It does not matter how slowly you go as long as you do not stop." – Confucius',
  '"What you get by achieving your goals is not as important as what you become by achieving your goals." – Zig Ziglar',
  '"Dream big and dare to fail." – Norman Vaughan',
  '"Hardships often prepare ordinary people for an extraordinary destiny." – C.S. Lewis',
  '"Don’t watch the clock; do what it does. Keep going." – Sam Levenson',
  '"Act as if what you do makes a difference. It does." – William James',
  '"Success usually comes to those who are too busy to be looking for it." – Henry David Thoreau',
  '"The way to get started is to quit talking and begin doing." – Walt Disney',
  '"Opportunities don’t happen. You create them." – Chris Grosser',
  '"It always seems impossible until it’s done." – Nelson Mandela',
  '"Don’t be afraid to give up the good to go for the great." – John D. Rockefeller',
  '"I find that the harder I work, the more luck I seem to have." – Thomas Jefferson',
  '"Success is walking from failure to failure with no loss of enthusiasm." – Winston Churchill',
  '"Don’t let yesterday take up too much of today." – Will Rogers',
  '"If you are not willing to risk the usual, you will have to settle for the ordinary." – Jim Rohn',
  '"The people who are crazy enough to think they can change the world are the ones who do." – Steve Jobs',
  '"The question isn’t who is going to let me; it’s who is going to stop me." – Ayn Rand',
  '"If you want something new, you have to stop doing something old." – Peter Drucker',
  '"The more you practice, the better you’ll get. The harder you work, the luckier you’ll become." – Anonymous',
  '"Your time is limited, don’t waste it living someone else’s life." – Steve Jobs',
  '"I am not a product of my circumstances. I am a product of my decisions." – Stephen R. Covey',
  '"Every child is an artist. The problem is how to remain an artist once he grows up." – Pablo Picasso',
  '"The road to success and the road to failure are almost exactly the same." – Colin R. Davis',
];

// Function to Display Random Quote
function displayRandomQuote() {
  const randomIndex = Math.floor(Math.random() * quotes.length); // Get random index
  const randomQuote = quotes[randomIndex]; // Get random quote
  document.getElementById('quote-display').innerText = randomQuote; // Display the quote
}

// Call the function on page load
window.onload = displayRandomQuote;
