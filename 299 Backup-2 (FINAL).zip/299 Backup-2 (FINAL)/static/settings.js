document.addEventListener('DOMContentLoaded', function () {
    // Function to show the modal with a message
    function showModal(message) {
        document.getElementById('modalMessage').innerText = message; // Set the modal message
        document.getElementById('modal').style.display = 'block'; // Display the modal
    }

    // Event listener for the "Save Changes" button
    document.getElementById('saveButton').addEventListener('click', function () {
        showModal('Your changes have been saved!'); // Show confirmation message
    });

    // Event listener for the close button in the modal
    document.getElementById('closeModal').addEventListener('click', function () {
        document.getElementById('modal').style.display = 'none'; // Close the modal
    });

    // Event listener to close the modal when clicking outside of it
    window.addEventListener('click', function (event) {
        const modal = document.getElementById('modal');
        if (event.target === modal) {
            modal.style.display = 'none'; // Close the modal
        }
    });

    // Function to confirm account deletion
    document.getElementById('deleteAccountButton').addEventListener('click', function () {
        if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
            showModal('Your account has been deleted.'); // Show confirmation message
        }
    });

    // Function to handle file upload
    document.getElementById('uploadLink').addEventListener('click', function (e) {
        e.preventDefault(); // Prevent default anchor behavior
        document.getElementById('fileInput').click(); // Trigger file input click
    });

    // Event listener for file input change
    document.getElementById('fileInput').addEventListener('change', function (event) {
        const file = event.target.files[0]; // Get the uploaded file
        if (file) {
            showModal(`Uploaded: ${file.name}`); // Show confirmation message with the file name
        }
    });

    // Event listener for "Download my data" link
    document.querySelector('.download-link').addEventListener('click', function (e) {
        e.preventDefault(); // Prevent default anchor behavior
        showModal('Your data is being prepared for download.'); // Show confirmation message
    });

    // Function to handle the search functionality
    document.querySelector('.search-container input').addEventListener('input', function () {
        const query = this.value.toLowerCase(); // Get the search query
        const sections = document.querySelectorAll('.section'); // Get all section elements

        sections.forEach(section => {
            const sectionText = section.innerText.toLowerCase(); // Get all text within the section
            if (sectionText.includes(query)) {
                section.style.display = 'block'; // Show section if it matches the query
            } else {
                section.style.display = 'none'; // Hide section if it doesn't match
            }
        });
    });

    // Dark mode toggle functionality
    const darkModeToggle = document.getElementById('darkModeToggle');

    // Check if dark mode preference is saved in localStorage
    if (localStorage.getItem('darkMode') === 'enabled') {
        darkModeToggle.checked = true;
    }

    darkModeToggle.addEventListener('change', function () {
        if (this.checked) {
            enableDarkMode();
        } else {
            disableDarkMode();
        }
    });

    function enableDarkMode() {
        localStorage.setItem('darkMode', 'enabled');

        // Send message to AskGPT iframe (if exists)
        const askGptIframe = window.parent.document.querySelector('iframe');
        if (askGptIframe) {
            askGptIframe.contentWindow.postMessage({ type: 'enable_dark_mode' }, '*');
        }

        // Optional: Send request to server
        fetch('/update_dark_mode', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ dark_mode: true })
        }).catch(error => {
            console.error('Error updating dark mode preference:', error);
        });
    }

    function disableDarkMode() {
        localStorage.setItem('darkMode', null);

        // Send message to AskGPT iframe (if exists)
        const askGptIframe = window.parent.document.querySelector('iframe');
        if (askGptIframe) {
            askGptIframe.contentWindow.postMessage({ type: 'disable_dark_mode' }, '*');
        }

        // Optional: Send request to server
        fetch('/update_dark_mode', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ dark_mode: false })
        }).catch(error => {
            console.error('Error updating dark mode preference:', error);
        });
    }

    // Initial check for dark mode on page load
    initializeDarkModeState();

    function initializeDarkModeState() {
        const darkModeEnabled = localStorage.getItem('darkMode') === 'enabled';
        darkModeToggle.checked = darkModeEnabled;
    }
});

// In settings.js, modify the download link event listener
document.querySelector('.download-link').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default anchor behavior
    
    // Send request to download data
    fetch('/download_data')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.blob();
        })
        .then(blob => {
            // Create a link to download the file
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = 'chat_history.pdf';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            
            showModal('Your data is being downloaded.'); // Show confirmation message
        })
        .catch(error => {
            console.error('Error downloading data:', error);
            showModal('Failed to download data. Please try again.');
        });
});