const monthYrElement = document.getElementById('monthYr');
const datesElement = document.getElementById('dates');
const prevB = document.getElementById('prevB');
const nxtB = document.getElementById('nxtB');

let currentDate = new Date();

const update = () => {
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();

    const firstDay = new Date(currentYear, currentMonth, 0);
    const lastDay = new Date(currentYear, currentMonth +1, 0);
    const totalDays = lastDay.getDate();
    const firstDayIndex = firstDay.getDay();
    const lastDayIndex = lastDay.getDay();

    const monthYrString = currentDate.toLocaleString('default', {month: 'long', year: 'numeric'});
    monthYrElement.textContent = monthYrString;

    let datesHTML ='';

    for(let i=firstDayIndex; i>0; i--){
        const prevDate = new Date(currentYear, currentMonth, 0 - i + 1);
        datesHTML += `<div class="date inactive">${prevDate.getDate()}</div>`;
    }

    for(let i=1; i<=totalDays; i++){
        const date = new Date(currentYear, currentMonth, i);
        const activeClass = date.toDateString() === new Date().
        toDateString() ? 'active' : '';
        datesHTML += `<div class="date ${activeClass}">${i}</div>`;
    }

    for(let i=1; i<= 7 - lastDayIndex; i++){
        const nextDate = new Date(currentYear, currentMonth + 1, i);
        datesHTML += `<div class="date inactive">${nextDate.getDate()}</div>`;
    }

    datesElement.innerHTML = datesHTML;
}

prevB.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    update();
})

nxtB.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    update();
})

update();