let chatCounter = 1; // Counter for chat IDs
let activeChat = null; // Track the currently active chat
let chats = {}; // Object to store all chat conversations
let chatToRename = null; // Chat to be renamed
let messageCounter = 0;

// Function to create a new chat
function createNewChat() {
    const chatId = `chat${chatCounter++}`;
    chats[chatId] = { messages: [] }; // Initialize chat messages

    const chatName = "New Chat"; // Default chat name
    const chatItem = document.createElement("div");
    chatItem.className = "chat-item"; // Set class for styling
    chatItem.id = chatId; // Set ID for tracking

    // Construct the chat item structure
    chatItem.innerHTML = `
        <span class="chat-name">${chatName}</span>
        <button class="rename-btn" onclick="openRenameModal('${chatId}')">✏️</button>
        <button class="delete-btn" onclick="deleteChat('${chatId}')">✖</button>
        <span class="date">${getCurrentDate()}</span>
    `;

    // Switch to the new chat upon creation
    chatItem.onclick = () => switchChat(chatId);
    document.getElementById("chatsList").appendChild(chatItem);

    switchChat(chatId); // Automatically switch to the new chat
}

// Function to delete a chat
function deleteChat(chatId) {
    delete chats[chatId]; // Remove from chats object
    document.getElementById(chatId).remove(); // Remove from the DOM

    if (activeChat === chatId) {
        activeChat = null; // Reset active chat if it was deleted
        document.getElementById("chatDisplay").innerHTML = ""; // Clear chat display
    }
}

// Function to switch to a selected chat
function switchChat(chatId) {
    activeChat = chatId; // Set the active chat
    const chat = chats[chatId];

    document.getElementById("chatDisplay").innerHTML = ""; // Clear current display
    chat.messages.forEach(({ sender, text }) => displayMessage(sender, text)); // Display chat messages
}

// Load chat history on page load
async function loadChatHistory() {
    const response = await fetch('/get_chat_history');
    const chatHistory = await response.json();

    if (response.ok) {
        chatHistory.forEach(({ sender, text, timestamp }) => {
            displayMessage(sender, text, timestamp);});
    } else {
        console.error("Error loading chat history:", chatHistory.error);
    }
}


function initializeDarkMode() {
    const darkModeEnabled = localStorage.getItem('darkMode') === 'enabled';
    
    if (darkModeEnabled) {
        enableDarkMode();
    } else {
        disableDarkMode();
    }

    // Listen for dark mode messages from settings page
    window.addEventListener('message', function(event) {
        if (event.data.type === 'enable_dark_mode') {
            enableDarkMode();
        } else if (event.data.type === 'disable_dark_mode') {
            disableDarkMode();
        }
    });
}

function enableDarkMode() {
    document.body.classList.add('dark-mode');
    localStorage.setItem('darkMode', 'enabled');
}

function disableDarkMode() {
    document.body.classList.remove('dark-mode');
    localStorage.setItem('darkMode', null);
}

document.addEventListener('DOMContentLoaded', initializeDarkMode);

// Function to handle sending a message
async function sendMessage() {
    const userInput = document.getElementById("userInput");
    const message = userInput.value.trim(); // Get user input
    if (!message) return; // Exit if the message is empty

    // Create a new chat if none exists
    if (!activeChat) createNewChat();

    // Set chat name as the first message if this is a new chat
    if (chats[activeChat].messages.length === 0) {
        document.querySelector(`#${activeChat} .chat-name`).textContent = message.slice(0, 20) + "...";
    }

    // Display and store the user's message
    chats[activeChat].messages.push({ sender: "user", text: message });
    displayMessage("user", message);
    userInput.value = ""; // Clear input field

    // Send the user's message to the backend and receive the bot response
    const response = await fetch('/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message })
    });

    const data = await response.json();

    // Display and store the bot's response
    const botMessage = data.bot_response;
    chats[activeChat].messages.push({ sender: "bot", text: botMessage });
    displayMessage("bot", botMessage);
}

// async function sendMessage() {
//     const userInput = document.getElementById("userInput");
//     const imageInput = document.getElementById("imageInput");
//     const message = userInput.value.trim();
//     const file = imageInput.files[0];

//     if (!message && !file) return; // Exit if there's no message or file

//     // Create a new chat if none exists
//     if (!activeChat) createNewChat();

//     // Set chat name as the first message if this is a new chat
//     if (chats[activeChat].messages.length === 0 && message) {
//         document.querySelector(`#${activeChat} .chat-name`).textContent = message.slice(0, 20) + "...";
//     }

//     // Display user's message
//     if (message) {
//         chats[activeChat].messages.push({ sender: "user", text: message });
//         displayMessage("user", message);
//     }

//     // Prepare data for backend
//     const formData = new FormData();
//     formData.append("message", message);
//     if (file) formData.append("file", file);

//     // Send data to backend
//     try {
//         const response = await fetch("/chat", {
//             method: "POST",
//             body: formData,
//         });

//         const data = await response.json();

//         // Display bot response
//         if (data.bot_response) {
//             chats[activeChat].messages.push({ sender: "bot", text: data.bot_response });
//             displayMessage("bot", data.bot_response);
//         }

//         // Display uploaded image
//         if (data.image_url) {
//             displayMessage("user", "Uploaded an image:", data.image_url);
//         }
//     } catch (error) {
//         console.error("Error sending message:", error);
//         alert("An error occurred. Please try again.");
//     }

//     // Clear inputs
//     userInput.value = "";
//     imageInput.value = "";
// }



document.getElementById("imageInput").addEventListener("change", async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
        const response = await fetch("/upload_image", {
            method: "POST",
            body: formData,
        });

        const data = await response.json();

        if (response.ok) {
            alert("Image uploaded successfully!");
            console.log("Image ID:", data.image_id);
        } else {
            alert(`Error: ${data.error}`);
        }
    } catch (error) {
        console.error("Failed to upload image:", error);
        alert("An unexpected error occurred.");
    }
});


document.addEventListener("DOMContentLoaded", loadChatHistory);

// Helper function to display messages in chat
function displayMessage(sender, text, timestamp = null) {
    const chatDisplay = document.getElementById("chatDisplay");
    const messageDiv = document.createElement("div");
    const formattedTime = timestamp || new Date().toLocaleString(); // Use provided timestamp or current time

    // Preprocess the text: Split into paragraphs if lines start with ***
    const paragraphs = text.split('\n').reduce((acc, line) => {
        if (' ') {
            acc.push(`<p>${line.slice().trim()}</p>`); // Remove the stars and add to a new paragraph
        } else {
            acc[acc.length - 1] += ` ${line.trim()}`; // Add to the last paragraph
        }
        return acc;
    }, ['']);
    
    // Combine all paragraphs into the final HTML
    const formattedText = paragraphs.map((p) => p.trim()).join('');

    // Apply message class and format content
    messageDiv.className = `message ${sender === 'user' ? 'user' : 'bot'}`;
    messageDiv.innerHTML = `
        <div>${formattedText}</div>
        <div class="message-meta">
            <span class="username">${sender === 'user' ? 'You' : 'Chatbot'}</span>
            <span class="timestamp">${formattedTime}</span>
        </div>
    `;

    chatDisplay.appendChild(messageDiv);
    chatDisplay.scrollTop = chatDisplay.scrollHeight; // Auto-scroll
}

// Open rename modal for a specific chat
function openRenameModal(chatId) {
    chatToRename = chatId; // Store the chat to rename
    document.getElementById("renameModal").style.display = "block"; // Show modal
}

// Close rename modal and clear selection
function closeRenameModal() {
    chatToRename = null; // Clear selection
    document.getElementById("renameModal").style.display = "none"; // Hide modal
}

// Rename the chat and update the display
function renameChat() {
    const newName = document.getElementById("renameInput").value.trim(); // Get new name
    if (newName && chatToRename) {
        document.querySelector(`#${chatToRename} .chat-name`).textContent = newName; // Update chat name
    }
    closeRenameModal(); // Close the modal
}

// Helper function to get the current date
function getCurrentDate() {
    return new Date().toLocaleDateString(); // Return formatted date
}


// // Function to clear all conversations and reset the chat list
// function clearAllConversations() {
//     chats = {}; // Reset chats object
//     activeChat = null; // Clear active chat

//     document.getElementById("chatDisplay").innerHTML = ""; // Clear display

//     const chatsList = document.getElementById("chatsList");
//     while (chatsList.firstChild) {
//         chatsList.removeChild(chatsList.firstChild); // Remove each chat item
//     }
// }

// Function to clear all conversations for the current user
async function clearAllConversations() {
    try {
        const response = await fetch('/clear_chats', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.success); // Optional: Display success message
            window.location.reload(); // Reload the page to see the cleared state
        } else {
            console.error('Error clearing chats:', data.error);
            alert('Failed to clear chats. Please try again.');
        }
    } catch (error) {
        console.error('Unexpected error clearing chats:', error);
        alert('An unexpected error occurred.');
    }
}


// Automatically start a new chat if user begins typing with no active chat
function initializeChatOnTyping() {
    const userInput = document.getElementById("userInput");
    userInput.addEventListener("input", () => {
        if (!activeChat && userInput.value.trim()) {
            createNewChat(); // Create new chat if user types
        }
    });
}

// Navigate to the account page
function goToAccountPage() {
    window.location.href = "/account"; // Adjust the URL as needed
}

// Log out the user
function logout() {
    alert("You have been logged out."); // Placeholder for logout confirmation
    window.location.href = "/login"; // Adjust the URL as needed
}

// Initialize the typing event listener after the page loads
document.addEventListener("DOMContentLoaded", initializeChatOnTyping);
