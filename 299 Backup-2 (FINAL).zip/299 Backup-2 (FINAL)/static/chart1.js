const ctx = document.getElementById('barchart').getContext('2d');
const barchart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Sub1', 'Sub2', 'Sub3', 'Sub4', 'Sub5', 'Subj6','Sub7', 'Sub8', 'Sub9', 'Sub10'],
        datasets: [{
            label: 'Syllabus completed',
            data: [8, 7, 3, 5, 2, 6, 4, 2, 9.5, 3],
            backgroundColor: [
                'rgba(57, 43, 113, 0.9)',
                'rgba(0, 2, 53, 0.9)',
                'rgba(57, 43, 113, 0.9)',
                'rgba(0, 2, 53, 0.9)',
                'rgba(57, 43, 113, 0.9)',
                'rgba(0, 2, 53, 0.9)',
                'rgba(57, 43, 113, 0.9)',
                'rgba(0, 2, 53, 0.9)',
                'rgba(57, 43, 113, 0.9)',
                'rgba(0, 2, 53, 0.9)'
            ],
            borderColor: [
                'rgba(57, 43, 113, 1)',
                'rgba(0, 2, 53, 1)',
                'rgba(57, 43, 113, 1)',
                'rgba(0, 2, 53, 1)',
                'rgba(57, 43, 113, 1)',
                'rgba(0, 2, 53, 1)',
                'rgba(57, 43, 113, 1)',
                'rgba(0, 2, 53, 1)',
                'rgba(57, 43, 113, 1)',
                'rgba(0, 2, 53, 1)'
            ],
            borderWidth: 0.5
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});