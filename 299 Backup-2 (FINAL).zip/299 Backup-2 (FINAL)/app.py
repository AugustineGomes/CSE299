# Create a virtual environment named venv
#   python -m venv venv

# Activate venv
#   venv\Scripts\activate

# deactivate venv
# deactivate

# pip install Flask

# pip freeze > requirements.txt
# pip freeze
# pip install -r requirements.txt
# pip install Flask-SQLAlchemy


# python app.py



from flask import Flask, jsonify, render_template, request, redirect, session, url_for, flash
#from flask_mysqldb import MySQL
#from models import db, User
from werkzeug.security import generate_password_hash, check_password_hash
#import config


from flask_sqlalchemy import SQLAlchemy
from flask import jsonify
# from sqlalchemy import ForeignKey, text, or_
# from sqlalchemy.orm import relationship
from datetime import datetime, timedelta
from google.oauth2 import id_token
from google.auth.transport import requests
import re

import io
from flask import send_file
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

app = Flask(__name__)
app.config['SECRET_KEY'] = 'temp-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///exam_helper_database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#app.config.from_object(config)

#app.config["SQLALCHEMY_DATABASE_URI"] = 'mysql://root:@localhost/Exam_Helper_Database'

# MySQL connection
# mysql = MySQL(app)
db = SQLAlchemy(app)
#db.init_app(app)

EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@(gmail\.com|yahoo\.com|hotmail\.com|outlook\.com|icloud\.com|aol\.com|zoho\.com|protonmail\.com)$'


# Secret key for session management
#app.secret_key = 'your_secret_key'
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=True)  # Must be nullable for Google Sign-In users
    google_id = db.Column(db.String(120), unique=True, nullable=True) 
    # Method to hash the password
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    # Method to check if password is correct
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
      # New Method to update profile
    def update_profile(self, first_name, last_name, password=None):
        self.first_name = first_name
        self.last_name = last_name
        if password:
            self.set_password(password)
class UploadedImage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)  # Associate with user
    image_path = db.Column(db.String(255), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now())


# app.py - Add Chat model
class Chat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    response = db.Column(db.String(500), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now()) 

    user = db.relationship('User', backref=db.backref('chats', lazy=True)) 
  
import google.generativeai as genai

# Configure the API
genai.configure(api_key="AIzaSyDEzbZuU68otQF3HZlly-DK7BdenRpACl0")

generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
    model_name="gemini-1.5-pro",
    generation_config=generation_config,
    system_instruction="Hello, I am your personal Study Guide. Feel free to ask me any doubts/queries.",
)


def is_valid_email(email):
    # Validate email using regular expression for specific domains
    return re.match(EMAIL_REGEX, email) is not None

# Route for the sign-up page
# @app.route('/signup', methods=['GET', 'POST'])

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('Contact.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Get form data
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = request.form['password']

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('User already exists. Please login.', 'warning')
            return redirect(url_for('login'))
       
         # Create new user and add to database
        if not is_valid_email(email):
            flash('Please enter a valid email address', 'danger')
            return redirect(url_for('signup'))
        
        new_user = User(first_name=first_name, last_name=last_name, email=email)
        new_user.set_password(password)  # Hash the password
        db.session.add(new_user)
        db.session.commit()

        flash('Account created successfully! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('sign-up.html')

# Route for the login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            
            session['user_id'] = user.id
            session['user_name'] = user.first_name
            
            session['show_flash'] = True
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials. Please try again.', 'danger')
            return redirect(url_for('login'))
    
    return render_template('login.html')


@app.route('/google_signin', methods=['POST'])
def google_signin():
    data = request.json
    token = data.get('token')

    if not token:
        return jsonify({'success': False, 'message': 'Token is missing'}), 400

    try:
        # Verify the token using Google's API
        idinfo = id_token.verify_oauth2_token(
            token,
            requests.Request(),
            "1049868383622-amgvu1qk2hrq0hml0qtt0e5j0akr0en6.apps.googleusercontent.com"
        )

        email = idinfo['email']
        name = idinfo['name']
        google_id = idinfo['sub']  # Unique Google ID

        # Check if the user exists
        user = User.query.filter_by(email=email).first()

        if not user:
            # Split full name into first and last name
            first_name, last_name = name.split(" ", 1) if " " in name else (name, "")
            
            # Create a new user
            user = User(
                first_name=first_name,
                last_name=last_name,
                email=email,
                google_id=google_id,
                password_hash=None  # Explicitly set password_hash to None
            )
            db.session.add(user)
            db.session.commit()

        # Log the user in
        session['user_id'] = user.id
        session['user_name'] = user.first_name
        session['show_flash'] = True
        return jsonify({'success': True})

    except ValueError as e:
        return jsonify({'success': False, 'message': str(e)}), 400


# Route for dashboard after successful login
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please log in to access the dashboard.', 'warning')
        return redirect(url_for('login'))
    
    # Display the flash message only if session['show_flash'] is True
    if session.get('show_flash'):
        flash('Login successful!', 'success')
        session.pop('show_flash')  # Remove the session variable after displaying the message

    return render_template('sidebar.html', user_name=session.get('user_name'))
    

# Route for settings after successful login
@app.route('/settings')
def settings():
    # Ensure the user is logged in
    if 'user_id' not in session:
        flash('You need to login first!', 'warning')
        return redirect(url_for('login'))
    
    # Retrieve the logged-in user from the database
    user = User.query.get(session['user_id'])

    # Pass the user object to the template
    return render_template('Settings.html', user=user)

# Route for schedule after successful login
@app.route('/schedule')
def schedule():
    # Ensure the user is logged in
    if 'user_id' not in session:
        flash('You need to login first!', 'warning')
        return redirect(url_for('login'))
    
    # Retrieve the logged-in user from the database
    user = User.query.get(session['user_id'])

    # Pass the user object to the template
    return render_template('schedule.html', user=user)

  
# app.py - Route for updating profile settings
@app.route('/update_profile', methods=['POST'])
def update_profile():
    # Ensure the user is logged in
    if 'user_id' not in session:
        flash('Please log in to update your profile.', 'warning')
        return redirect(url_for('login'))
    
    # Fetch the current user from the database
    user = User.query.get(session['user_id'])

    # Get form data
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    password = request.form.get('password')
    
    # Update user profile with provided data
    user.update_profile(first_name=first_name, last_name=last_name, password=password)
    
    # Commit changes to the database
    db.session.commit()

    flash('Profile updated successfully!', 'success')
    return redirect(url_for('settings'))

@app.route('/update_dark_mode', methods=['POST'])
def update_dark_mode():
    data = request.json
    dark_mode = data.get('dark_mode', False)
    # Save dark mode preference to user's profile/session
    # This is a placeholder - implement according to your authentication system
    session['dark_mode'] = dark_mode
    return jsonify({"status": "success"})

@app.route('/askgpt')
def askgpt():
    # Render the AskGPT page
    return render_template('askgpt.html')

import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'static/uploads'  # Directory to store uploaded images
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Helper function to check file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/upload_image', methods=['POST'])
def upload_image():
    if 'user_id' not in session:
        return jsonify({'error': 'User not logged in'}), 401

    user_id = session['user_id']
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    if file and allowed_file(file.filename):
        # Ensure the upload folder exists
        if not os.path.exists(app.config['UPLOAD_FOLDER']):
            os.makedirs(app.config['UPLOAD_FOLDER'])  # Create the directory if it doesn't exist

        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        # Save image metadata to the database
        uploaded_image = UploadedImage(user_id=user_id, image_path=file_path)
        db.session.add(uploaded_image)
        db.session.commit()

        return jsonify({'success': True, 'image_id': uploaded_image.id})
    else:
        return jsonify({'error': 'Invalid file format'}), 400



    
@app.route('/chat', methods=['POST'])
def chat():
    if 'user_id' not in session:
        return jsonify({'error': 'User not logged in'}), 401

    user_id = session['user_id']
    user_message = request.json.get('message')
   
    
    # Get bot response using the API
    chat_session = model.start_chat(history=[
        {
            "role": "user",
            "parts": ["Hello"],
        },
        {
        "role": "model",
        "parts": [
            "Hi there! How can I help you today?  Do you have any questions you'd like to ask or topics you'd like to discuss?\n",
          ],
        },
    ]
    )
    response = chat_session.send_message(user_message)

    bot_response = response.text.strip()  # Get the bot's response text

    # Save the user message and bot response in the database
    user_chat = Chat(
        user_id=user_id,
        message=user_message,
        response="",
        timestamp=datetime.now()
    )
    db.session.add(user_chat)

    bot_chat = Chat(
        user_id=user_id,
        message="",
        response=bot_response,
        timestamp=datetime.now()
    )
    db.session.add(bot_chat)

    db.session.commit()

    return jsonify({
        'user_message': user_message,
        'bot_response': bot_response,
        'timestamp': bot_chat.timestamp.strftime('%Y-%m-%d %H:%M:%S')  # Format timestamp for frontend
    })



# app.py - Route to get chat history with both user and bot messages
@app.route('/get_chat_history', methods=['GET'])
def get_chat_history():
    if 'user_id' not in session:
        return jsonify({'error': 'User not logged in'}), 401

    user_id = session['user_id']
    chats = Chat.query.filter_by(user_id=user_id).order_by(Chat.timestamp).all()

    chat_history = []
    for chat in chats:
        if chat.message:
            chat_history.append({'sender': 'user', 'text': chat.message, 'timestamp': chat.timestamp.strftime('%Y-%m-%d %H:%M:%S')})
        if chat.response:
            chat_history.append({'sender': 'bot', 'text': chat.response, 'timestamp': chat.timestamp.strftime('%Y-%m-%d %H:%M:%S')})

    return jsonify(chat_history)

#Download Data
@app.route('/download_data', methods=['GET'])
def download_data():
    if 'user_id' not in session:
        flash('Please log in to download your data.', 'warning')
        return redirect(url_for('login'))

    user_id = session['user_id']
    
    # Fetch chat history for the user
    chats = Chat.query.filter_by(user_id=user_id).order_by(Chat.timestamp).all()

    # Create a PDF buffer
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    # Add title
    title = Paragraph("My Chat History", styles['Title'])
    story.append(title)
    story.append(Spacer(1, 12))

    # Add user details
    user = User.query.get(user_id)
    user_info = Paragraph(f"Name: {user.first_name} {user.last_name}", styles['Normal'])
    story.append(user_info)
    story.append(Spacer(1, 12))

    # Add chat messages
    for chat in chats:
        if chat.message:  # User message
            user_msg = Paragraph(f"You: {chat.message}", styles['Normal'])
            story.append(user_msg)
            story.append(Spacer(1, 6))
        
        if chat.response:  # Bot response
            bot_msg = Paragraph(f"Assistant: {chat.response}", styles['Normal'])
            story.append(bot_msg)
            story.append(Spacer(1, 6))

    # Build PDF
    doc.build(story)

    # Move buffer position to the beginning
    buffer.seek(0)
    
    return send_file(
        buffer, 
        as_attachment=True, 
        download_name='chat_history.pdf', 
        mimetype='application/pdf'
    )

@app.route('/clear_chats', methods=['POST'])
def clear_chats():
    if 'user_id' not in session:
        return jsonify({'error': 'User not logged in'}), 401

    user_id = session['user_id']
    
    # Delete all chats for the current user
    Chat.query.filter_by(user_id=user_id).delete()
    db.session.commit()

    return jsonify({'success': 'All chats cleared successfully'})


# Logout route
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_name', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables if not exist
    app.run(debug=True)
